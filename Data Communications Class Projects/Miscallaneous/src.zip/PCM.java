import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.text.DecimalFormat;


class PCM
{
	Graphics g;
	
	PCM(Graphics g){
		this.g=g;
		g.drawString("PAM Value:", 10, 225);
		g.drawString("Quantization:", 0, 245);
		g.drawString("PCM Code:", 10, 265);
		g.drawString("Code Number", 45, 25);
	}

	public void paint(Graphics g)
	{
		int k;
		int j=0;
		for(k=0;k<16;k++)
		{
			if(k == 0)
			{
				g.drawLine(80, 200-j, 85, 200-j);
			}
			else
			{
				g.drawLine(75, 200-j, 85, 200-j);
			}
			g.drawString(String.valueOf(k), 60, 205-j);
			j=j+10;
		}
		
		Graphics2D g2=(Graphics2D)g;
		g2.setStroke(new BasicStroke(0.1f));

		int i,temp;
		int valueofgraph;
		double doublevalue;
		DecimalFormat df = new DecimalFormat("###.#");
		DecimalFormat df2 = new DecimalFormat("###");
		df2.setRoundingMode(java.math.RoundingMode.DOWN);
		int p;
		for(i = 0; i <= 340; i=i+30)
		{
			valueofgraph=140 - (int)(50 * getSineVal((i / 340.0) * 2* Math.PI));
			doublevalue=190-(125-(50 * getSineVal((i / 340.0) * 2* Math.PI)));
			temp=Integer.parseInt(df2.format( ((doublevalue/160)*15) ));
			g.drawLine(i + 80,200,i+80, 210);
			g.drawRect(i+80, valueofgraph, 30, 200-valueofgraph);		
			g.drawString(df.format( ((doublevalue/160)*15) ), i+75, 225);
			g.drawString(df2.format( ((doublevalue/160)*15) ), i+75, 245);
			g.drawString(Integer.toBinaryString((temp)), i+75, 265);
		}
	}
	
	double getSineVal(double x) 
	{
		return Math.sin(x);
	}
}